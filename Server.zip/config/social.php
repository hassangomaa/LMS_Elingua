<?php

return [
    'allowFacebook' => saasEnv('ALLOW_FACEBOOK_LOGIN', 'false'),
    'allowGoogle' => saasEnv('ALLOW_GOOGLE_LOGIN', 'false'),
];
