<?php

return [
    'name' => 'VimeoSetting'
];
