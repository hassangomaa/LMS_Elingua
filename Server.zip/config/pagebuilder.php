<?php

return [
    'name' => 'PageBuilder'
];
