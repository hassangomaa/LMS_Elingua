<?php

return [
    'name' => 'VirtualClass'
];
