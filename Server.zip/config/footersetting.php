<?php

return [
    'name' => 'FooterSetting'
];
