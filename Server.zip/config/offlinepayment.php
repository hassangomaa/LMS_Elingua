<?php

return [
    'name' => 'OfflinePayment'
];
