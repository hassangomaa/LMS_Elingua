<?php

return [
    'name' => 'Coupons'
];
