<?php

return [
    'name' => 'Certificate'
];
