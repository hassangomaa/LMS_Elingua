<?php

return [
    'name' => 'NotificationSetup'
];
