<?php

return [
    'name' => 'Quiz'
];
