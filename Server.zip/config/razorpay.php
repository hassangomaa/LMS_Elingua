<?php

return [
    'name' => 'Razorpay'
];
