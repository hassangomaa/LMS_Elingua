<?php

return [
    'name' => 'VdoCipher'
];
