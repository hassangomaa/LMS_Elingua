<?php

return [
    'dirs' => ['/app', '/public', '/config', '/routes', '/resources','/Modules'],
];
