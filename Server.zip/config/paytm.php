<?php

return [
    'name' => 'Paytm'
];
