<?php

return [
    'name' => 'Payeer'
];
