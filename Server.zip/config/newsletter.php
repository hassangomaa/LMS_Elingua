<?php

return [
    'name' => 'Newsletter'
];
