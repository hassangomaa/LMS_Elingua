<?php

return [
    'name' => 'CourseSetting'
];
