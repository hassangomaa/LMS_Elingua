<?php

return [
    'name' => 'SystemSetting'
];
