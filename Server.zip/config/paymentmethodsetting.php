<?php

return [
    'name' => 'PaymentMethodSetting'
];
