<?php

return [
    'name' => 'StudentSetting'
];
