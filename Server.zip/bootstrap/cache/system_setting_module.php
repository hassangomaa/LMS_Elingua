<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SystemSetting\\Providers\\SystemSettingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SystemSetting\\Providers\\SystemSettingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);