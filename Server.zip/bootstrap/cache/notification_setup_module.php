<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\NotificationSetup\\Providers\\NotificationSetupServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\NotificationSetup\\Providers\\NotificationSetupServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);