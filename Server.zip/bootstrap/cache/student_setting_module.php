<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\StudentSetting\\Providers\\StudentSettingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\StudentSetting\\Providers\\StudentSettingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);