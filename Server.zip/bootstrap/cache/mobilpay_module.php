<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Mobilpay\\Providers\\MobilpayServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Mobilpay\\Providers\\MobilpayServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);