<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Backup\\Providers\\BackupServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Backup\\Providers\\BackupServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);