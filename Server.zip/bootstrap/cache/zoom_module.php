<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Zoom\\Providers\\ZoomServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Zoom\\Providers\\ZoomServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);