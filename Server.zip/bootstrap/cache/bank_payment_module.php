<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BankPayment\\Providers\\BankPaymentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BankPayment\\Providers\\BankPaymentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);