<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Quiz\\Providers\\QuizServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Quiz\\Providers\\QuizServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);