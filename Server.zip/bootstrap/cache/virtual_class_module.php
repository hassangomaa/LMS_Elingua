<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VirtualClass\\Providers\\VirtualClassServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VirtualClass\\Providers\\VirtualClassServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);