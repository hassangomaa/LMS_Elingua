<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\VdoCipher\\Providers\\VdoCipherServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\VdoCipher\\Providers\\VdoCipherServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);