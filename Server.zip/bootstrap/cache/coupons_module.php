<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Coupons\\Providers\\CouponsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Coupons\\Providers\\CouponsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);