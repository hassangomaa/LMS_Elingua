<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Pesapal\\Providers\\PesapalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Pesapal\\Providers\\PesapalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);